# Load Library
library(tensorflow)

# Load Data 
datasets <- tf$contrib$learn$datasets
mnist <- datasets$mnist$read_data_sets("MNIST-data", one_hot = TRUE)

# Start an interactive Session
# This means the computation graph may be changeged interactively
sess <- tf$InteractiveSession()

# Define (empty) placeholders for inputs
# NULL allows the first dimension (n pictures/labels) to be any size
x <- tf$placeholder(tf$float32, shape(NULL, 784L)) # Photo variable, 28 x 28 pixels
y_ <- tf$placeholder(tf$float32, shape(NULL, 10L)) # Label variable, 0-9

# Define model parameters as variables
# Variables live inside the computation graph
W <- tf$Variable(tf$zeros(shape(784L, 10L))) # Weights, 784 inputs 10 outputs
b <- tf$Variable(tf$zeros(shape(10L))) # Biases, 10 classes
# Initiate all variables 
sess$run(tf$initialize_all_variables()) # This function will be updated in march 2017

# Define the model and Loss
y <- tf$nn$softmax(tf$matmul(x,W) + b)
# sum across all classes, then average
cross_entropy <- tf$reduce_mean(-tf$reduce_sum(y_ * tf$log(y), reduction_indices=1L))

# Train the model
# Automatic differentiation allows TF to find the loss gradients
# So we only need to specify the optimization algorithm and step length
optimizer <- tf$train$GradientDescentOptimizer(0.5)
# The function train_step will now simultaneously:
# 1. Compute Gradient 2. compute parameters 3. update steps 4. apply update steps to the parameters
train_step <- optimizer$minimize(cross_entropy)
# Now we start the training
# Each batch with 100 photos
for (i in 1:1000) {
  batches <- mnist$train$next_batch(100L) # use the train set of mnist data
  batch_xs <- batches[[1]] # split in photos
  batch_ys <- batches[[2]] # and classes
  sess$run(train_step,
           feed_dict = dict(x = batch_xs, y_ = batch_ys))
}

# Evaluate Model
correct_prediction <- tf$equal(tf$argmax(y, 1L), tf$argmax(y_, 1L)) # argmax gives the max value
accuracy <- tf$reduce_mean(tf$cast(correct_prediction, tf$float32))
accuracy$eval(feed_dict=dict(x = mnist$test$images, y_ = mnist$test$labels)) # use test set
