# Install API
# require(devtools)
# devtools::install_github("rstudio/tensorflow")

# Load Library
library(tensorflow)


# Load Data 
# One-hot encode the classes
datasets <- tf$contrib$learn$datasets
mnist <- datasets$mnist$read_data_sets("MNIST-data", one_hot = TRUE)

ptm <- proc.time()
# Start an interactive Session
# This means the computation graph may be changeged interactively
# Else one must give the entire graph in one action to TF
sess <- tf$InteractiveSession()

# Initialize Weights and biases
# Because there are so many W and b to initialize we create a function for it
weight_variable <- function(shape) {
  initial <- tf$truncated_normal(shape, stddev=0.1) # add random noise
  tf$Variable(initial) # create variable
}
bias_variable <- function(shape) {
  initial <- tf$constant(0.1, shape=shape) # add random noise
  tf$Variable(initial) # create variable
}

# Define (empty) placeholders for inputs
# NULL allows the first dimension (n of pictures/labels) to be any size
# Reminder: We converted the 2D pictures into a intensity vector of length 28x28=784
x <- tf$placeholder(tf$float32, shape(NULL, 784L)) # Picture variable, 28 x 28 pixels
y_ <- tf$placeholder(tf$float32, shape(NULL, 10L)) # Label variable, 0-9


# Define convolution function
# Because we always use the same strides and padding
# x: a 4-D image input (n,height,width,channel)
# W: a 4-D Filter input (height, width, in_channel, out_channel)
conv2d <- function(x, W) {
  tf$nn$conv2d(x, W, strides=c(1L, 1L, 1L, 1L), padding='SAME')
}

# Define Pooling function
# Because we always us the same size, strides and paddings
# x: a 4-D image input (n,height,width,channel)
max_pool_2x2 <- function(x) {
  tf$nn$max_pool(
    x, 
    ksize=c(1L, 2L, 2L, 1L),
    strides=c(1L, 2L, 2L, 1L), 
    padding='SAME')
}

# First convolution
# Initiliaze variables through our functions
# Values: 5x5 Patch, 1 Input channel, 32 Features
W_conv1 <- weight_variable(shape(5L, 5L, 1L, 32L))
b_conv1 <- bias_variable(shape(32L))
# Reshape into image again (-1 infers the value according to the others, 28x28 Pixel, color channel)
x_image <- tf$reshape(x, shape(-1L, 28L, 28L, 1L))
# Convolute 
h_conv1 <- tf$nn$relu(conv2d(x_image, W_conv1) + b_conv1)
# Pooling
h_pool1 <- max_pool_2x2(h_conv1)

# Second convolution
W_conv2 <- weight_variable(shape = shape(5L, 5L, 32L, 64L))
b_conv2 <- bias_variable(shape = shape(64L))
x_image <- tf$reshape(x, shape(-1L, 28L, 28L, 1L))
h_conv2 <- tf$nn$relu(conv2d(h_pool1, W_conv2) + b_conv2)
h_pool2 <- max_pool_2x2(h_conv2)

# Fully connected layer
# Now the image size is 28/2/2=7, 64 features, 1024 Neurons
W_fc1 <- weight_variable(shape(7L * 7L * 64L, 1024L))
b_fc1 <- bias_variable(shape(1024L))
h_pool2_flat <- tf$reshape(h_pool2, shape(-1L, 7L * 7L * 64L))
h_fc1 <- tf$nn$relu(tf$matmul(h_pool2_flat, W_fc1) + b_fc1)

# Apply Dropout
keep_prob <- tf$placeholder(tf$float32)
h_fc1_drop <- tf$nn$dropout(h_fc1, keep_prob)

# Readout softmax layer
W_fc2 <- weight_variable(shape(1024L, 10L))
b_fc2 <- bias_variable(shape(10L))

# Define the Model
y_conv <- tf$nn$softmax(tf$matmul(h_fc1_drop, W_fc2) + b_fc2)

# Train and Evaluate
# We need a loss function
cross_entropy <- tf$reduce_mean(-tf$reduce_sum(y_ * tf$log(y_conv), reduction_indices=1L))
train_step <- tf$train$AdamOptimizer(1e-4)$minimize(cross_entropy)
# And a evaluation metric
correct_prediction <- tf$equal(tf$argmax(y_conv, 1L), tf$argmax(y_, 1L))
accuracy <- tf$reduce_mean(tf$cast(correct_prediction, tf$float32))
# Initialize all the variables
sess$run(tf$initialize_all_variables())

# Keep in mind: so far no computations were done
# We only built the graph of computations

# Train the model 
for (i in 1:1200) {
  # 50 Examples per batch
  # 1,000/50 = 20 Epochs
  batch <- mnist$train$next_batch(50L)
  # report every 100th batch
  if (i %% 100 == 0) {
    train_accuracy <- accuracy$eval(feed_dict = dict(
      x = batch[[1]], y_ = batch[[2]], keep_prob = 1.0))
    cat(sprintf("step %d, training accuracy %g\n", i, train_accuracy))
  }
  train_step$run(feed_dict = dict(
    x = batch[[1]], y_ = batch[[2]], keep_prob = 0.5))
}

# Test the model
train_accuracy <- accuracy$eval(feed_dict = dict(
  x = mnist$test$images, y_ = mnist$test$labels, keep_prob = 1.0))
print(proc.time()-ptm)
cat(sprintf("test accuracy %g", train_accuracy))
