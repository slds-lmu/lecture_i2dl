

require(ggplot2)
cpu_1<-as.data.frame(matrix(data = c(1, 2.351,2,0.962,8,0.810),nrow = 3))

cpu_n<-c(1,2,8)
cpu_s<-c(2.351,0.962,0.810)

ccpu_n<-c(1,8,16,32)
ccpu_s<-c(0.828,0.547,0.530,0.549)


#### 
# Main PLot FCN-5
plot(cpu_n,cpu_s,type = "l",xlim = c(1,32), ylim= c(0.3,3),lwd=2, col="blue",
     main="CPU Scaling in the FCN-5", xlab="Number of CPUs",ylab="Computation time [s]")
points(cpu_n,cpu_s,cex=2,pch=21,col="blue",bg="blue")
lines(ccpu_n,ccpu_s,lwd=2,col="blue")
points(ccpu_n,ccpu_s,cex=2,pch=24,col="blue",bg="blue",type="b")

cpu_tf <- c(7.206,2.626,1.934)
ccpu_tf <- c(2.804,1.574,0.857,0.595)
lines(cpu_n,cpu_tf,lwd=2,col="red")
points(cpu_n,cpu_tf,cex=2,pch=21,col="red",bg="red")
lines(ccpu_n,ccpu_tf,lwd=2,col="red")
points(ccpu_n,ccpu_tf,cex=2,pch=24,col="red",bg="red")

cpu_torch_n <- c(1,2)
cpu_torch <- c(1.227,0.661)
ccpu_torch <- c(0.536,0.440,0.425,0.892)
lines(cpu_torch_n,cpu_torch,lwd=2,col="darkgreen")
points(cpu_torch_n,cpu_torch,cex=2,pch=21,col="darkgreen",bg="darkgreen")

lines(ccpu_n,ccpu_torch,lwd=2,col="darkgreen")
points(ccpu_n,ccpu_torch,cex=2,pch=24,col="darkgreen",bg="darkgreen")

legend(20,3,
       pt.bg=c("red","red","blue","blue","darkgreen","darkgreen"),
       pt.cex=c(1.5,1.5,1.5,1.5,1.5,1.5),
       cex=1.5,
       pch=c(21,24,21,24,21,24),
       legend = c("CNTK","CNTK cluster","Tensorflow","Tensorflow cluster","Torch","Torch cluster")
       )

#### 
# Main PLot FCN-5 GPU
# Main PLot FCN-5
plot(cpu_n,cpu_s,type = "l",xlim = c(1,32), ylim= c(0.025,0.7),lwd=1, col="blue",
     main="AlexNet", xlab="Number of CPUs",ylab="Computation time [s]")
points(cpu_n,cpu_s,cex=1,pch=21,col="blue",bg="blue")
lines(ccpu_n,ccpu_s,lwd=1,col="blue")
points(ccpu_n,ccpu_s,cex=1,pch=24,col="blue",bg="blue",type="b")

cpu_tf <- c(7.206,2.626,1.934)
ccpu_tf <- c(2.804,1.574,0.857,0.595)
lines(cpu_n,cpu_tf,lwd=1,col="red")
points(cpu_n,cpu_tf,cex=1,pch=21,col="red",bg="red")
lines(ccpu_n,ccpu_tf,lwd=1,col="red")
points(ccpu_n,ccpu_tf,cex=1,pch=24,col="red",bg="red")

cpu_torch_n <- c(1,2)
cpu_torch <- c(1.227,0.661)
ccpu_torch <- c(0.536,0.440,0.425,0.892)
lines(cpu_torch_n,cpu_torch,lwd=1,col="darkgreen")
points(cpu_torch_n,cpu_torch,cex=1,pch=21,col="darkgreen",bg="darkgreen")

lines(ccpu_n,ccpu_torch,lwd=1,col="darkgreen")
points(ccpu_n,ccpu_torch,cex=1,pch=24,col="darkgreen",bg="darkgreen")

gpu_n <- c(10,15,20)
gpu_cn <- c(0.044,0.033,0.053)
points(gpu_n,gpu_cn,cex=3,pch=3,col="blue",bg="blue")
gpu_tf <- c(0.070,0.063,0.089)
points(gpu_n,gpu_tf,cex=3,pch=3,col="red",bg="red")
gpu_tr <- c(0.044,0.046,0.055)
points(gpu_n,gpu_tr,cex=3,pch=3,col="darkgreen",bg="darkgreen")


legend(25,0.4,
       pt.bg=c("blue","blue","red","red","darkgreen","darkgreen"),
       pt.cex=c(1.5,1.5,1.5,1.5,1.5,1.5),
       cex=1,
       pch=c(24,3,24,3,24,3),
       legend = c("CNTK cluster","CNTK GPU","Tensorflow cluster","Tensorflow GPU","Torch cluster","Torch GPU")
)


#### 
# Main PLot alex-nnet und lstm-64
# Main PLot FCN-5

# CTNK
a_cpu <- c(6.451,2.140,2.063)
a_ccpu  <- c(2.319,1.684,1.223,1.292)
plot(cpu_n,a_cpu,type = "l",xlim = c(1,32), ylim= c(0,3),lwd=1, col="blue",
     main="Alex-Net", xlab="Number of CPUs",ylab="Computation time [s]")
points(cpu_n,a_cpu,cex=1,pch=21,col="blue",bg="blue")
lines(ccpu_n,a_ccpu,lwd=1,col="blue")
points(ccpu_n,a_ccpu,cex=1,pch=24,col="blue",bg="blue",type="b")



# TF
a_cpu_tf <- c(3.935,1.694,1.453)
a_ccpu_tf <- c(1.865,1.067,0.666,0.914)
lines(cpu_n,a_cpu_tf,lwd=1,col="red")
points(cpu_n,a_cpu_tf,cex=1,pch=21,col="red",bg="red")
lines(ccpu_n,a_ccpu_tf,lwd=1,col="red")
points(ccpu_n,a_ccpu_tf,cex=1,pch=24,col="red",bg="red")


# Torch
a_cpu_torch <- c(4.621,1.400,3.034)
a_ccpu_torch <- c(1.312,1.114,1.122,1.229)
lines(cpu_n,a_cpu_torch,lwd=1,col="darkgreen")
points(cpu_n,a_cpu_torch,cex=1,pch=21,col="darkgreen",bg="darkgreen")
lines(ccpu_n,a_ccpu_torch,lwd=1,col="darkgreen")
points(ccpu_n,a_ccpu_torch,cex=1,pch=24,col="darkgreen",bg="darkgreen")

legend(20,3,
       pt.bg=c("red","red","blue","blue","darkgreen","darkgreen"),
       pt.cex=c(1.5,1.5,1.5,1.5,1.5,1.5),
       cex=1,
       pch=c(21,24,21,24,21,24),
       legend = c("CNTK","CNTK cluster","Tensorflow","Tensorflow cluster","Torch","Torch cluster")
)

#####
# main plot lstm
# CTNK


l_cpu_n <- c(8.218,2.483,2.762)
l_ccpu <- c(2.662,1.949,1.527,1.798)
plot(cpu_n,l_cpu_n,type = "l",xlim = c(1,32), ylim= c(1,5),lwd=1, col="blue",
     main="LSTM-64", xlab="Number of CPUs",ylab="Computation time [s]")
points(cpu_n,l_cpu_n,cex=1,pch=21,col="blue",bg="blue")
lines(ccpu_n,l_ccpu,lwd=1,col="blue",lty=2)
points(ccpu_n,l_ccpu,cex=1,pch=24,col="blue",bg="blue")


# TF

l_cpu_tf <- c(11.699,3.516,3.477)
l_ccpu_tf <- c(4.402,2.525,1.590,1.469)
lines(cpu_n,l_cpu_tf,lwd=1,col="red",lty=2)
points(cpu_n,l_cpu_tf,cex=1,pch=21,col="red",bg="red")
lines(ccpu_n,l_ccpu_tf,lwd=1,col="red",lty=2)
points(ccpu_n,l_ccpu_tf,cex=1,pch=24,col="red",bg="red")

# Torch
l_cpu_torch <- c(9.623,4.980,6.976)
l_ccpu_torch <- c(4.054,3.252,3.358,5.815)
lines(cpu_n,l_cpu_torch,lwd=1,col="darkgreen",lty=2)
points(cpu_n,l_cpu_torch,cex=1,pch=21,col="darkgreen",bg="darkgreen")
lines(ccpu_n,l_ccpu_torch,lwd=1,col="darkgreen",lty=2)
points(ccpu_n,l_ccpu_torch,cex=1,pch=24,col="darkgreen",bg="darkgreen")

legend(20,4.5,
       pt.bg=c("red","red","blue","blue","darkgreen","darkgreen"),
       pt.cex=c(1.5,1.5,1.5,1.5,1.5,1.5),
       cex=1,
       pch=c(21,24,21,24,21,24),
       legend = c("CNTK","CNTK cluster","Tensorflow","Tensorflow cluster","Torch","Torch cluster")
)



