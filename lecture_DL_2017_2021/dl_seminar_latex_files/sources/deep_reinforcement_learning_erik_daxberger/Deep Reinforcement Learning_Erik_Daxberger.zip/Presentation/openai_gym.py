import gym

env = gym.make("Pong-v0")
s_0 = env.reset()

for _ in range(1000):
    env.render()

    a_t = env.action_space.sample()

    s_t1, r_t1, done, info = env.step(a_t)
