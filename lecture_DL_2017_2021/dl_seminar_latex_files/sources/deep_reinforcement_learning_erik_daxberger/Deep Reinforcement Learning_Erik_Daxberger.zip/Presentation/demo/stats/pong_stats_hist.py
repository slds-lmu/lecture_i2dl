""" A little python script to visualize the statistics for the Pong demo, using matplotlib """

import matplotlib
# use a different backend -> figures can be closed using the keyboard!
matplotlib.use('TKAgg')

import numpy as np
import matplotlib.pyplot as plt

# declare variables
eps = []
rew = []

# open results file and load data
fname = 'results_hist_1.txt'
with open(fname) as f:
    for line in f:
        current = line.split(',')
        eps.append(int(current[0]))
        rew.append(float(current[1]))

# plot graph
num_bins = 14
n, bins, pathes = plt.hist(rew, num_bins, ec='black')
#plt.figure(figsize=(8,5))
#plt.errorbar(eps, mean, std)
mean = np.mean(rew)
plt.plot((mean, mean), (0, 18), 'r')


#plt.axis([eps[0],eps[-1]])
plt.title('Distribution of the last 100 rewards $r_t$')
plt.xlabel('Reward $r_t$')
plt.ylabel('Frequency')

# show and save figure
#plt.show()
plt.savefig('pong_stats_hist.eps', format='eps', dpi=1000)
