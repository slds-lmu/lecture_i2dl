""" A little python script to visualize the statistics for the Pong demo, using matplotlib """

import matplotlib
# use a different backend -> figures can be closed using the keyboard!
matplotlib.use('TKAgg')

import numpy as np
import matplotlib.pyplot as plt

# declare variables
eps = []
mean = []
std = []
time = []

# open results file and load data
fname = 'results_10000.txt'
with open(fname) as f:
    for line in f:
        current = line.split(',')
        eps.append(int(current[0]))
        mean.append(float(current[1]))
        std.append(np.sqrt(float(current[2])))
        time.append(float(current[3]))

# plot graph
plt.figure(figsize=(8,5))
plt.errorbar(eps, mean, std)
plt.plot(eps, [0]*len(eps), 'r')


#plt.axis([eps[0],eps[-1]])
plt.title('Evolution of the reward $r_t$ over time')
plt.xlabel('episode')
plt.ylabel('$r_t:$ mean $\pm$ std')

# show and save figure
#plt.show()
plt.savefig('pong_stats.eps', format='eps', dpi=1000)
