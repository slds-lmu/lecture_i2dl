data_org = read.csv("data/numberMatrix.csv", sep=";")

# list with all numbers represented by a 5x3 matrix
digits = lapply(1:10, function(x) matrix(as.numeric(data_org[x,2:16]), nrow=5, byrow = TRUE))
empty_digit = matrix(rep(0,15), ncol = 3)
empty_row = matrix(rep(0,5), ncol = 1)

#################################-#
# Build the data from 1 to 999 ####
# the matrix will have 999 rows
# a row represents the pixels of a number in a 5x11 grid
num_grid = matrix(NA, nrow = 999, ncol = 55)

# write first 9 lines:
for (j in 1:9) {
  num_grid[j, ] = as.vector(t(cbind(empty_digit, empty_row, empty_digit, empty_row, digits[[j]])))
}

# write lines 10 - 99:
for (i in 1:9) {
  for (j in 0:9) {
    jt = j
    if(j==0) jt = 10
    row = i*10 + j
    num_grid[row, ] = as.vector(t(cbind(empty_digit, empty_row, digits[[i]], empty_row, digits[[jt]])))
  }
}

# make it 3 digits
for (i in 1:9) {
  for (j in 0:9) {
    jt = j
    if(j==0) jt = 10
    for (k in 0:9) {
      kt = k
      if(k==0) kt = 10
      row = i*100 + j*10 + k
      num_grid[row, ] = as.vector(t(cbind(digits[[i]], empty_row, digits[[jt]], empty_row, digits[[kt]])))
    }
  }
}

save(num_grid, file = "numbers5x11grid-data.Rda")
