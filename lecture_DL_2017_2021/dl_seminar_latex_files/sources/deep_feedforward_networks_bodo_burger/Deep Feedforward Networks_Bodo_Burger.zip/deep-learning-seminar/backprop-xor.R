input = c(1, 0, 1)

# sigmoid function:
s = function(x) (1+exp(-x))^(-1)
ds = function(x) s(x) * (1 - s(x))
# initial weights:

w_h1 = c(-.07, .22, -.46)
w_h2 = c(.94, .46, .1)
w_o1 = c(-.22, .58, .78)

########################-#
# forward propagation ####
h1_in = sum(input * w_h1)
h2_in = sum(input * w_h2)

h1_out = s(h1_in)
h2_out = s(h2_in)

o1_in = sum(c(h1_out, h2_out, 1) * w_o1)

o1_out = s(o1_in)


# error function:
E = o1_out - 1

# deltas:
d_o1 = E*ds(o1_in)
d_h1 = ds(h1_in) * (w_o1[1] * d_o1)
d_h2 = ds(h2_in) * (w_o1[2] * d_o1)

# gradients O1
G_o1 = c(h1_out, h2_out, 1) * d_o1

## gradients H1
G_h1 = input * d_h1

# gradients H2
G_h2 = input * d_h2


##################-#
# weight update ####

w_h1_new = w_h1 - 0.7 * G_h1
w_h2_new = w_h2 - 0.7 * G_h2
w_o1_new = w_o1 - 0.7 * G_o1


######################-#
# test forward prop ####

h1_in_new = sum(input * w_h1_new)
h2_in_new = sum(input * w_h2_new)

h1_out_new = s(h1_in_new)
h2_out_new = s(h2_in_new)

o1_in_new = sum(c(h1_out_new, h2_out_new, 1) * w_o1_new)

o1_out_new = s(o1_in_new)



##############
# Total error

# old weights:
## 0,0: -0.27
## 0,1: -0.26
## 1,0: -0.24
## 1,1: -0.24
## total error:
0.5 * sum(c(-.27, -.26, .24, .24)^2)
# 0.12785

# new weights:
## 0,0: -0.26
## 0,1: -0.25
## 1,0: -0.23
## 1,1: -0.23
## total error:
0.5 * sum(c(-.26,-.25,-.23,-.23)^2)
# 0.11795






