# README #

This repository contains the presentation, the report and several test files about deep feedforward networks as part of the Master's seminar
"Introduction to Deep Learning" at LMU München, winter term 2016/17.

### Sources ###

Both the presentation and report are heavily based on chapter 6
of the deep learning book by Ian Goodfellow, Yoshua Bengio and Aaron Courville
(http://www.deeplearningbook.org/).