#####################-#
# plotting a digit ####

library(ggplot2)
library(reshape2)

print_number = function(number) {
  # number: a number between 1-999 on a 5X11 grid
  # works with negative values

  dat <- melt(matrix(number, nrow = 5, byrow = TRUE))

  ggplot(dat, aes(Var1, Var2, fill = value)) +
    geom_tile(colour = "grey") +
    scale_fill_gradient2(low = "red", high = "blue", mid = "white", midpoint = 0) +
    scale_x_reverse() + coord_flip() + xlab("") + ylab("")
}

##############################################################################-#

# activation function
acti = function(x, w) sum(x * w)

# classification function
classi = function(h) if(h>=0) 1 else -1

# learning rule
learn = function(w, p, y, eta) {
  x = as.numeric(p)
  return(w + eta * x * y)
}

# perceptron:
perceptron = function(X, y, w, eta, max_reps, max_error_rate = 0, print_pattern = FALSE) {
  j = integer(max_reps)
  h = apply(X, 1, acti, w = w)
  W = matrix(ncol = length(w), nrow = max_reps)

  for(t in 0:(max_reps-1)) {
    y_hat = sapply(h, classi)
    miss = (y_hat != y)

    if(mean(miss) <= max_error_rate) {
      print(paste("At least ", (1-max_error_rate)*100, "% of all points correctly classified!", sep = ""))
      print("Number of iterations:")
      print(t)
      if(t>0) {
        if(print_pattern == TRUE) {
          print("Learning pattern:")
          print(j[1:t])
        }
      } else {
        print("No learning necessary. Weights were fine!")
      }
      break
    }

    j[t+1] = sample(which(miss), 1)
    w = learn(w, X[j[t+1], ], y[j[t+1]], eta)
    h = apply(X, 1, acti, w = w)
    W[t+1,] = w
  }

  if(mean(miss) > max_error_rate) {
    print(paste("No convergence after", max_reps, "rounds."))
    print(paste("Missclassification rate:", mean(miss)))
    #print("Learning pattern:")
    #print(j)
  }

  # final_weights = w
  # print("Learning rate:")
  # print(eta)
  # print("Final weights:")
  return(list(final_weights = w, activation = h, all_weights = W, used_examples = j))
}
