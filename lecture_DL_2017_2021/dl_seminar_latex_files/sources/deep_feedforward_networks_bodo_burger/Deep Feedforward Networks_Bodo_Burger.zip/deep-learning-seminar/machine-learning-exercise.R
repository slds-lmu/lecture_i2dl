rm(list = ls())

# Learning even/odd ####
#
# I try to learn odd/even for numbers between 1-99
# with a simple network


# this data contains all digits from 0-9
# one row contains the pixel in a 5x3 grid by row

load("numbers5x11grid-data.Rda")

source("numbers5x11grid-all-functions.R")

#####################-#
# plotting a digit ####

# examples:
print_number(num_grid[3,])
print_number(num_grid[58,])
print_number(num_grid[99,])
print_number(num_grid[100,])
print_number(num_grid[208,])
print_number(num_grid[990,])

##############################################################################-#
# num_grid is our feature matrix
X = num_grid

##############################################################################-#
# creating the target variable: ####
# even/odd:
## target: "1" if even, "-1" if odd:
y <- rep(c(0,1), 500)[-1000]
y[5]
y[56]
y[998]
y[999]


##############################################################################-#
# Does a linear model work?
# TODO: linear model with gradient descent

#X = cbind(rep(1,99), zahlen)
#y = rep(c(0,1), 500)[-1000]

df = data.frame(y = rep(c(0,1), 500)[-1000], X)

fit = glm(y ~ ., family = binomial(link = "logit"), data = df)
summary(fit)

cf = fit$coefficients
cf = sapply(cf, function(x) if(is.na(x)) 0 else x)

lin.pred = sum(cf * X[58,])
exp(lin.pred) / (1+exp(lin.pred))

##############################################################################-#

######################################################-#
# Use the data to train a perceptron such that it distinguishes
# between odd and even numbers. Vary w and η.
# Additionally: does the perceptron learning rule terminate for the problem “is a multiple of 3”?

# number of features and number of obs
m = ncol(X)
n = nrow(X)

# learning parameter:
eta = .1

# initial weights:
w <- rep(0.01, m)
w <- rep(0.001, m)
w <- rnorm(m, 1)
w <- w / (m*sum(w))

## target: "1" if even, "-1" if odd:
y <- rep(c(-1,1), 500)[-1000]


fit = perceptron(X, y, w, 0.1, 80, 0.1)
fit = perceptron(X[651:699,], y[651:699], w, 0.01, 300)

fit$activation[1:10]

acti(fit$final_weights, X[1,])
print(fit$final_weights)
print_number(w)
print_number(fit$all_weights[1,])
print_number(fit$all_weights[2,])
print_number(fit$all_weights[3,])
print_number(fit$all_weights[4,])
print_number(fit$all_weights[5,])
print_number(fit$all_weights[6,])
print_number(fit$all_weights[7,])
print_number(fit$all_weights[10,])
print_number(fit$all_weights[15,])
print_number(fit$all_weights[20,])
print_number(fit$all_weights[30,])
print_number(fit$all_weights[40,])
print_number(fit$all_weights[50,])
print_number(fit$all_weights[60,])
print_number(fit$all_weights[70,])
print_number(fit$final_weights)

##############################################################################-#
# new target: "is multiple of 4" ####
# "1" if "multiple of 4", "-1" otherwise
y = rep(-1, 999)
y[(1:999) %% 4 == 0] = 1
y[800:817]

fit = perceptron(X, y, w, 0.1, 300, 0.05)
## missclassrate around .25

##############################################################################-#
# new target: "is multiple of 5" ####
# "1" if "multiple of 4", "-1" otherwise
y = rep(-1, 999)
y[(1:999) %% 5 == 0] = 1
y[800:817]

fit = perceptron(X, y, w, 0.1, 300)
## works (number of rounds > 200)

##############################################################################-#
# new target: "is multiple of 7" ####
# "1" if "multiple of 4", "-1" otherwise
y = rep(-1, 999)
y[(1:999) %% 7 == 0] = 1
y[800:817]

fit = perceptron(X, y, w, 0.1, 3000)
## missclassrate: .14...

##############################################################################-#
# new target: "is multiple of 3" ####
# "1" if "multiple of 3", "-1" otherwise
y = rep(-1, 999)
y[(1:999) %% 3 == 0] = 1
y[99:109]
y[998:999]

fit = perceptron(X, y, w, 0.01, 3000)
## missclassrate stays above .4


##############################################################################-#
# Building a net ####
# TODO

perceptron = function(X, y, w, eta, max_reps, print_pattern = FALSE) {
  j = integer(max_reps)
  h = apply(X, 1, acti, w = w)

  for(t in 0:(max_reps-1)) {
    y_hat = sapply(h, classi)
    miss = (y_hat != y)

    if(sum(miss) == 0) {
      print("All points correctly classified!")
      print("Number of rounds:")
      print(t)
      if(t>0) {
        if(print_pattern == TRUE) {
          print("Learning pattern:")
          print(j[1:t])
        }
      } else {
        print("No learning necessary. Weights were fine!")
      }
      break
    }

    j[t+1] = sample(which(miss), 1)
    w = learn(w, X[j[t+1], ], y[j[t+1]])
    h = apply(X, 1, acti, w = w)
  }

  if(sum(miss) != 0) {
    print(paste("No convergence after", max_reps, "rounds."))
    print(paste("Missclassification rate:", mean(miss)))
    #print("Learning pattern:")
    #print(j)
  }

  # final_weights = w
  # print("Learning rate:")
  # print(eta)
  # print("Final weights:")
  return(list(final_weights = w, activation = h))
}


##############################################################################-#
# using neuaralnet-package ####
library(neuralnet)

# activation functions:
sigmoid = function(x) (1+exp(-x))^(-1)
ReLU = Vectorize(function(x) if(x>0) return(x) else return(0))

data = data.frame(y, num_grid)

formula = paste("y ~", paste(names(data)[-1], collapse = " + "))

# 1 hidden layer , 1 node:
fit = neuralnet(formula, data = data, hidden =1)
# 1 hidden layer, 2 nodes:
fit = neuralnet(formula, data = data, hidden =2)
plot(fit, rep = "best")


weights = fit_nn_1$weights[[1]]
weights = fit_nn_2$weights[[1]]
# TODO print weights in 5x11 grid
print_number(weights[[1]][-1,1])

pred_nn_1 = compute(fit_nn_1, data[300:320, -1])
pred_nn_2 = compute(fit_nn_2, data[300:320, -1])


# 2 hidden layer, 2 nodes:
fit_nn_22 = neuralnet(formula, data = data, hidden =c(2,2))
plot(fit_nn_22)

compute(fit_nn_22, data[, -1])

#
fit = neuralnet(formula, data = data, hidden =c(2,2,2))
plot(fit)
compute(fit, data[300:320, -1])

################################################-#
# Tests neuralnet-package ####
data(infert, package="datasets")
print(net.infert <- neuralnet(case~parity+induced+spontaneous, infert,
                              err.fct="ce", linear.output=FALSE, likelihood=TRUE))
gwplot(net.infert, selected.covariate="parity")
gwplot(net.infert, selected.covariate="induced")
gwplot(net.infert, selected.covariate="spontaneous")




##############################################################################-#
# Blatt 1 Machine Learning SoSe 2016 ####
# Perceptron

##########################################-#
# Exercise 1-3 perceptron learning rule ####

# data:

x0 <- rep(1, 4)
x1 <- c(2, 1, 0.5, 0)
x2 <- c(4, .5, 1.5, .5)
y <- c(1, 1, -1, -1)

data <- data.frame(x0, x1, x2, y)

# number of features and number of obs
m <- ncol(data) - 1L
n <- nrow(data)

# learning parameter:
eta = .25

# activation function
acti <- function(x, w) sum(x * w)
acti(data[1,1:3], w)

# classification function
classi <- function(h) if(h>=0) 1 else -1
classi(-4)
classi(0)

# learning rule
learn <- function(w, p) {
  x <- as.numeric(p)
  return(w + eta * x[-length(x)] * x[length(x)])
}

learn(w, data[1,])

# initial weights:
w <- c(0, 1, -1)

# pattern-based learning:

for(t in 0:20) {
  print(paste("Step ", t, ":", sep = ""))

  h <- apply(data[,1:m], 1, acti, w = w)
  y_hat <- sapply(h, classi)
  miss <- (y_hat != data[ , m+1])
  print(data.frame(h, y_hat, y = data[ , m+1], miss))

  if(mean(miss) == 0) {
    print("################################")
    print("All points correctly classified!")
    print("Final weights:")
    print(w)
    break
  }

  j <- sample(which(miss), 1)
  print(paste("Learning rule with pattern", j))

  w <- learn(w, data[j, ])
  print(paste("New weights:"))
  print(w)
  print("------------------------------")
}

# plot the separating line:
a <- -w[1]/w[3]
b <- -w[2]/w[3]
plot(data[,2], data[,3])
abline(a, b, col = "red")
