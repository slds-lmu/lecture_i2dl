concrete <- read.csv2("data/Concrete_Data.csv")
str(concrete)


#### normalize data ####
# typically ANN work best when input data are scaled to a narrow range
# around zero

normalize = function(x) {
  return((x - min(x)) / (max(x) - min(x)))
}

concrete_norm = as.data.frame(lapply(concrete, normalize))

summary(concrete)
summary(concrete_norm)

#### training / test set ####
n = nrow(concrete)
train = sample(c(FALSE, TRUE), n, replace = TRUE, prob = c(.25, .75))
test = !train


#### training the model ####
library(neuralnet)

concrete_model = neuralnet(strength ~ cement + slag + ash + water + superplastic
                           + coarseagg + fineagg + age, data = concrete_norm[train,])
plot(concrete_model)


#### evaluating model performance ####
model_results = compute(concrete_model, concrete_norm[test, 1:8])
predicted_strength = model_results$net.result

cor(predicted_strength, concrete_norm[test, "strength"])


#### improving model performance ####
concrete_model2 = neuralnet(strength ~ cement + slag + ash + water
                            + superplastic + coarseagg + fineagg + age,
                           data = concrete_norm[train,], hidden = 5)
plot(concrete_model2)
model_results2 = compute(concrete_model2, concrete_norm[test, 1:8])
predicted_strength2 = model_results2$net.result

cor(predicted_strength2, concrete_norm[test, "strength"])
